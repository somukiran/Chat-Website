var ids = {
  facebook: {
    clientID: 'get your own',
    clientSecret: 'get your own'
  }
}
// please get your own IDs. :)
module.exports = ids;
